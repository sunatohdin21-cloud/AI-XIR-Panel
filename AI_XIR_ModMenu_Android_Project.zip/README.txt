AI XIR Android Panel — Exita King Edition

Ini adalah source project Android Studio (Java), bukan APK yang sudah dikompilasi.
Fitur: panel dark/red, tab Principal/Ajuste/Gelo/IA/Bypass, toggle UI, slider preset.
Semua kontrol bersifat lokal/demo. Tidak melakukan injeksi ke Free Fire, auto-headshot,
bypass anti-cheat, atau menjanjikan anti-ban.

Cara build:
1. Ekstrak ZIP.
2. Buka folder AI_XIR_ModMenu_Android di Android Studio.
3. Izinkan Gradle sync dan install Android SDK 35 jika diminta.
4. Pilih Build > Build APK(s).
5. APK biasanya ada di app/build/outputs/apk/debug/app-debug.apk.
