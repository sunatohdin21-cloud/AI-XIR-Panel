package com.exita.aixir;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8, 8, 10);
    private final int PANEL = Color.rgb(19, 19, 22);
    private final int RED = Color.rgb(239, 20, 34);
    private final int WHITE = Color.rgb(245, 245, 245);
    private final int MUTED = Color.rgb(160, 160, 168);
    private LinearLayout content;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        TextView header = new TextView(this);
        header.setText("  AI XIR  //  EXITA KING");
        header.setTextColor(WHITE);
        header.setTextSize(20);
        header.setTypeface(Typeface.DEFAULT_BOLD);
        header.setPadding(18, 20, 18, 20);
        header.setBackgroundColor(RED);
        root.addView(header);

        status = new TextView(this);
        status.setText("● PANEL ONLINE  •  CONFIG DEMO");
        status.setTextColor(Color.rgb(255, 90, 90));
        status.setTextSize(11);
        status.setPadding(18, 12, 18, 10);
        root.addView(status);

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.HORIZONTAL);
        body.setPadding(10, 4, 10, 10);
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.VERTICAL);
        nav.setBackground(round(PANEL, 14));
        body.addView(nav, new LinearLayout.LayoutParams(dp(112), -1));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        body.addView(scroll, new LinearLayout.LayoutParams(0, -1, 1));
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(12, 6, 4, 12);
        scroll.addView(content);

        addNav(nav, "✥  Principal", "Principal");
        addNav(nav, "⚙  Ajuste", "Ajuste");
        addNav(nav, "✦  Gelo", "Gelo");
        addNav(nav, "ϟ  IA", "IA");
        addNav(nav, "⬡  Bypass", "Bypass");
        showPage("Principal");
        setContentView(root);
    }

    private void addNav(LinearLayout nav, String label, String page) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextColor(WHITE);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(10, 18, 6, 18);
        b.setBackground(round(page.equals("Ajuste") ? RED : PANEL, 9));
        nav.addView(b, new LinearLayout.LayoutParams(-1, -2));
        b.setOnClickListener(v -> {
            for (int i = 0; i < nav.getChildCount(); i++)
                nav.getChildAt(i).setBackground(round(PANEL, 9));
            b.setBackground(round(RED, 9));
            showPage(page);
        });
    }

    private void showPage(String page) {
        content.removeAllViews();
        title(page.toUpperCase());
        if (page.equals("Principal")) {
            note("AI XIR CONFIGURATION PANEL", "Panel Android bergaya mod menu. Pengaturan di sini hanya preset lokal/demo.");
            toggle("Panel aktif", true);
            toggle("Tampilkan status", true);
            toggle("Simpan preset lokal", false);
        } else if (page.equals("Ajuste")) {
            note("AJUSTES", "Atur preset latihan dan tampilan. Tidak mengubah memori game.");
            slider("General Sensitivity", 0, 200, 150);
            slider("Red Dot", 0, 200, 135);
            slider("2x Scope", 0, 200, 120);
            slider("FOV Preview", 60, 150, 100);
        } else if (page.equals("Gelo")) {
            note("VISUAL / AIM TRAINING", "Kontrol untuk latihan dan tampilan panel.");
            toggle("Crosshair preview", true);
            toggle("Aim training guide", false);
            toggle("FPS counter demo", false);
        } else if (page.equals("IA")) {
            note("AI XIR TOOLS", "Utilitas panel lokal.");
            toggle("Quick config", true);
            toggle("Show notifications", true);
            toggle("Auto-save preset", false);
        } else {
            note("BYPASS", "Tab ini hanya placeholder visual. Tidak ada bypass anti-cheat atau injeksi game.");
            toggle("Demo status indicator", false);
            TextView warning = new TextView(this);
            warning.setText("Mode aman: panel tidak menyuntikkan kode ke game dan tidak menjamin anti-ban.");
            warning.setTextColor(MUTED);
            warning.setTextSize(12);
            warning.setPadding(0, 12, 0, 12);
            content.addView(warning);
        }
    }

    private void title(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(WHITE);
        t.setTextSize(18);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(4, 6, 4, 14);
        content.addView(t);
    }

    private void note(String heading, String body) {
        TextView h = new TextView(this);
        h.setText(heading);
        h.setTextColor(RED);
        h.setTextSize(13);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        content.addView(h);
        TextView d = new TextView(this);
        d.setText(body);
        d.setTextColor(MUTED);
        d.setTextSize(12);
        d.setPadding(0, 6, 0, 12);
        content.addView(d);
    }

    private void toggle(String label, boolean checked) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(WHITE);
        s.setTextSize(13);
        s.setChecked(checked);
        s.setPadding(4, 8, 4, 8);
        content.addView(s, new LinearLayout.LayoutParams(-1, -2));
        s.setOnCheckedChangeListener((button, isChecked) ->
            status.setText("● PANEL ONLINE  •  " + label + ": " + (isChecked ? "ON" : "OFF")));
    }

    private void slider(String label, int min, int max, int value) {
        TextView l = new TextView(this);
        l.setText(label + "  [" + value + "]");
        l.setTextColor(WHITE);
        l.setTextSize(13);
        l.setPadding(4, 10, 4, 0);
        content.addView(l);
        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(value - min);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(RED));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(RED));
        content.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                l.setText(label + "  [" + (p + min) + "]");
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
